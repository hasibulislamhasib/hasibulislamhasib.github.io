import { PortfolioData, SkillItem, EducationItem } from './types';

export const PORTFOLIO_DATA: PortfolioData = {
  fullName: 'HM Hasibul Islam Hasib',
  displayName: 'Hasib Islam',
  nickname: 'Hasib',
  location: 'Dinajpur, Bangladesh',
  quote: 'I love expressing my thoughts through beautiful designs while constantly learning new things.',
  currentRoles: ['Poster Designer', 'Graphic Designer', 'Web Designer'],
  currentlyLearning: 'Web Design',
  futureGoal: 'Professional Web Developer',
  qualifications: 'Hafez + SSC 2026',
  phone: '01750996769',
  formattedPhone: '+880 1750-996769',
  whatsAppNumber: '01750996769',
  whatsAppInternational: '8801750996769',
  facebookUrl: 'https://www.facebook.com/share/1DhzvRxF5G/',
};

// Exactly the 7 skills specified by the user, honest and professional
export const SKILLS_LIST: SkillItem[] = [
  {
    id: 'canva',
    name: 'Canva',
    category: 'Design',
    description: 'Creating impactful social media graphics, branding visuals, and clean digital compositions.',
    iconName: 'LayoutTemplate',
  },
  {
    id: 'photoshop',
    name: 'Photoshop',
    category: 'Design',
    description: 'Image manipulation, detailed photo retouching, visual styling, and asset preparation.',
    iconName: 'Image',
  },
  {
    id: 'poster-design',
    name: 'Poster Design',
    category: 'Design',
    description: 'Crafting expressive, high-contrast poster layouts with focused typography and visual rhythm.',
    iconName: 'FileText',
  },
  {
    id: 'graphic-design',
    name: 'Graphic Design',
    category: 'Design',
    description: 'Visual identity creation, color balance, typography pairing, and modern aesthetic design.',
    iconName: 'Palette',
  },
  {
    id: 'web-design',
    name: 'Web Design',
    category: 'Development',
    description: 'Designing intuitive, responsive, and aesthetically structured interfaces for the modern web.',
    iconName: 'MonitorSmartphone',
  },
  {
    id: 'video-editing',
    name: 'Video Editing',
    category: 'Visual & Media',
    description: 'Sequencing, pace cutting, audio synchronization, and refined video presentations.',
    iconName: 'Video',
  },
  {
    id: 'photography',
    name: 'Photography',
    category: 'Visual & Media',
    description: 'Visual composition, framing, natural lighting capture, and real-world perspective storytelling.',
    iconName: 'Camera',
  },
];

// Exact education credentials without inventing institutions or grades
export const EDUCATION_LIST: EducationItem[] = [
  {
    title: 'Hafez',
    badge: 'Religious Achievement',
    subtitle: 'Islamic Studies & Quranic Memorization',
    description: 'Completion of Quranic memorization (Hifz), developing discipline, dedication, focus, and perseverance.',
    status: 'Completed',
  },
  {
    title: 'SSC 2026',
    badge: 'Academic',
    subtitle: 'Secondary School Certificate',
    description: 'Active candidate preparing for the Secondary School Certificate examination in 2026.',
    status: 'Upcoming / Candidate',
  },
];
