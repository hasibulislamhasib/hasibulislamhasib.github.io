export type ThemeMode = 'dark' | 'light';

export interface SkillItem {
  id: string;
  name: string;
  category: 'Design' | 'Visual & Media' | 'Development';
  description: string;
  iconName: string;
}

export interface EducationItem {
  title: string;
  badge: string;
  subtitle: string;
  description: string;
  status: 'Completed' | 'Upcoming / Candidate';
}

export interface PortfolioData {
  fullName: string;
  displayName: string;
  nickname: string;
  location: string;
  quote: string;
  currentRoles: string[];
  currentlyLearning: string;
  futureGoal: string;
  qualifications: string;
  phone: string;
  formattedPhone: string;
  whatsAppNumber: string;
  whatsAppInternational: string;
  facebookUrl: string;
}
