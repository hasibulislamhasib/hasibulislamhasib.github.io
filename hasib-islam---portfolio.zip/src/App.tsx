import React, { useState, useEffect } from 'react';
import { ThemeMode } from './types';
import { LoadingScreen } from './components/LoadingScreen';
import { SubtleBackground } from './components/SubtleBackground';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Education } from './components/Education';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { PhotoManagerModal } from './components/PhotoManagerModal';
import { Image as ImageIcon } from 'lucide-react';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('hasib_portfolio_theme');
    if (saved === 'light' || saved === 'dark') return saved;
    return 'dark'; // Dark mode default as specified with green accents
  });

  const [customPhotoUrl, setCustomPhotoUrl] = useState<string | null>(() => {
    return localStorage.getItem('hasib_custom_bg_photo') || null;
  });

  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  // Sync theme changes with DOM and localStorage
  useEffect(() => {
    localStorage.setItem('hasib_portfolio_theme', theme);
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
  }, [theme]);

  // Handle custom photo selection
  const handleSelectCustomPhoto = (url: string | null) => {
    setCustomPhotoUrl(url);
    if (url) {
      localStorage.setItem('hasib_custom_bg_photo', url);
    } else {
      localStorage.removeItem('hasib_custom_bg_photo');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!isDraggingFile) setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        handleSelectCustomPhoto(result);
        fetch('/api/upload-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ dataUrl: result }),
        }).catch(() => {});
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Section visibility tracking for active nav state
  useEffect(() => {
    const sections = ['home', 'about', 'skills', 'education', 'contact'];
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`min-h-screen relative flex flex-col font-sans selection:bg-emerald-500 selection:text-neutral-950 transition-colors duration-300 ${
        theme === 'dark' ? 'bg-[#090b0a] text-neutral-100' : 'bg-[#f8faf9] text-neutral-900'
      }`}
    >
      {/* Drag & Drop Overlay Indicator */}
      {isDraggingFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm border-4 border-dashed border-emerald-500 pointer-events-none p-6 text-center">
          <div className="p-6 rounded-2xl bg-neutral-900 border border-emerald-500/50 shadow-2xl">
            <ImageIcon className="w-12 h-12 text-emerald-400 mx-auto mb-3 animate-pulse" />
            <div className="text-lg font-bold text-white mb-1">
              Drop Your Photo Here
            </div>
            <p className="text-xs text-emerald-400">
              Your photo will be integrated as the subtle background texture
            </p>
          </div>
        </div>
      )}

      {/* 1. Loading Screen */}
      {loading && <LoadingScreen onFinished={() => setLoading(false)} />}

      {/* 2. Integrated Subtle Background with Personal Photo */}
      <SubtleBackground theme={theme} customPhotoUrl={customPhotoUrl} />

      {/* 3. Sticky Navbar */}
      <Navbar
        theme={theme}
        onToggleTheme={toggleTheme}
        activeSection={activeSection}
      />

      {/* 4. Main Portfolio Sections */}
      <main id="main-content" className="relative z-10 flex-grow">
        <Hero theme={theme} />
        <About theme={theme} />
        <Skills theme={theme} />
        <Education theme={theme} />
        <Contact theme={theme} />
      </main>

      {/* 5. Footer */}
      <Footer theme={theme} />

      {/* 6. Subtle Personal Photo Reference & Preview Helper */}
      <div className="fixed bottom-4 left-4 z-30 hidden sm:block">
        <button
          type="button"
          id="photo-reference-btn"
          onClick={() => setIsPhotoModalOpen(true)}
          className={`px-3 py-1.5 rounded-full text-[11px] font-medium border flex items-center gap-1.5 transition-all shadow-sm backdrop-blur-md cursor-pointer ${
            theme === 'dark'
              ? 'border-neutral-800 bg-neutral-900/80 text-neutral-400 hover:text-emerald-400 hover:border-emerald-500/40'
              : 'border-neutral-200 bg-white/80 text-neutral-600 hover:text-emerald-700 hover:border-emerald-600/40'
          }`}
          title="Personal background photo configuration"
        >
          <ImageIcon className="w-3.5 h-3.5 text-emerald-500" />
          <span>Background: hasib-photo.jpg</span>
        </button>
      </div>

      {/* 7. Personal Photo Manager Modal */}
      <PhotoManagerModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        theme={theme}
        customPhotoUrl={customPhotoUrl}
        onSelectCustomPhoto={handleSelectCustomPhoto}
      />
    </div>
  );
}
