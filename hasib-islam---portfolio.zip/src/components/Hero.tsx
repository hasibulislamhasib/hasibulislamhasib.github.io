import React from 'react';
import { MapPin, Phone, MessageCircle, ArrowDown, ExternalLink } from 'lucide-react';
import { ThemeMode } from '../types';
import { PORTFOLIO_DATA } from '../portfolioData';

interface HeroProps {
  theme: ThemeMode;
}

export const Hero: React.FC<HeroProps> = ({ theme }) => {
  const scrollToAbout = () => {
    const aboutEl = document.getElementById('about');
    if (aboutEl) {
      aboutEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[92vh] flex items-center justify-center pt-28 pb-16 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-4xl mx-auto w-full text-center">
        {/* Location pill with subtle emerald indicator */}
        <div
          className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full border mb-8 backdrop-blur-md transition-all duration-300 ${
            theme === 'dark'
              ? 'border-emerald-500/30 bg-emerald-950/30 shadow-[0_0_20px_rgba(16,185,129,0.12)]'
              : 'border-emerald-900/15 bg-white/80 shadow-sm'
          }`}
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
          <span
            className={`text-xs font-semibold tracking-wide ${
              theme === 'dark' ? 'text-emerald-300' : 'text-emerald-800'
            }`}
          >
            {PORTFOLIO_DATA.location}
          </span>
        </div>

        {/* Primary Prominent Name */}
        <h1
          id="hero-name"
          className={`text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight mb-5 transition-colors duration-300 ${
            theme === 'dark' ? 'text-white' : 'text-neutral-900'
          }`}
        >
          {PORTFOLIO_DATA.displayName}
        </h1>

        {/* Subtitle / Roles with Deep Emerald styling */}
        <div className="mb-6">
          <p
            id="hero-roles"
            className="text-base sm:text-xl md:text-2xl font-semibold tracking-wide text-emerald-500"
          >
            {PORTFOLIO_DATA.currentRoles.join('  •  ')}
          </p>
        </div>

        {/* Short Personal Quote */}
        <div className="max-w-2xl mx-auto mb-10">
          <blockquote
            id="hero-quote"
            className={`text-base sm:text-lg italic font-normal leading-relaxed transition-colors duration-300 ${
              theme === 'dark' ? 'text-neutral-300' : 'text-neutral-700'
            }`}
          >
            &ldquo;{PORTFOLIO_DATA.quote}&rdquo;
          </blockquote>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3.5 sm:gap-4 mb-14">
          {/* WhatsApp Direct Chat - Luxurious Solid Emerald Button */}
          <a
            id="hero-whatsapp-btn"
            href={`https://wa.me/${PORTFOLIO_DATA.whatsAppInternational}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-neutral-950 font-bold text-sm tracking-wide transition-all duration-300 shadow-[0_4px_24px_rgba(5,150,105,0.28)] hover:shadow-[0_6px_32px_rgba(16,185,129,0.4)] hover:-translate-y-0.5 cursor-pointer border border-emerald-400/30"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Chat on WhatsApp</span>
          </a>

          {/* Clickable Phone Number - Refined Glass Button */}
          <a
            id="hero-call-btn"
            href={`tel:${PORTFOLIO_DATA.phone}`}
            className={`inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl border font-semibold text-sm tracking-wide transition-all duration-300 cursor-pointer ${
              theme === 'dark'
                ? 'border-emerald-500/30 bg-[#0c100d]/80 text-emerald-300 hover:bg-emerald-950/40 hover:border-emerald-400 hover:shadow-[0_0_20px_rgba(16,185,129,0.2)] hover:-translate-y-0.5'
                : 'border-emerald-800/20 bg-white text-emerald-800 hover:bg-emerald-50 hover:border-emerald-600 shadow-sm hover:-translate-y-0.5'
            }`}
          >
            <Phone className="w-4 h-4 text-emerald-500" />
            <span>Call: {PORTFOLIO_DATA.phone}</span>
          </a>

          {/* Facebook Link - Subtle High-Contrast Button */}
          <a
            id="hero-facebook-btn"
            href={PORTFOLIO_DATA.facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-2 px-5 py-3.5 rounded-xl border font-medium text-sm transition-all duration-300 cursor-pointer ${
              theme === 'dark'
                ? 'border-neutral-800/90 bg-[#0c100d]/60 text-neutral-300 hover:text-white hover:border-neutral-700 hover:-translate-y-0.5'
                : 'border-neutral-200 bg-white text-neutral-700 hover:text-neutral-900 hover:border-neutral-300 shadow-sm hover:-translate-y-0.5'
            }`}
          >
            <ExternalLink className="w-4 h-4 text-emerald-500" />
            <span>Facebook Profile</span>
          </a>
        </div>

        {/* Scroll indicator button */}
        <button
          id="hero-scroll-down-btn"
          onClick={scrollToAbout}
          type="button"
          aria-label="Scroll to About section"
          className={`inline-flex flex-col items-center gap-2 text-xs font-medium transition-colors cursor-pointer ${
            theme === 'dark'
              ? 'text-neutral-400 hover:text-emerald-400'
              : 'text-neutral-600 hover:text-emerald-700'
          }`}
        >
          <span className="tracking-wider uppercase text-[11px] font-semibold">Explore Profile</span>
          <ArrowDown className="w-4 h-4 text-emerald-500 animate-bounce" />
        </button>
      </div>
    </section>
  );
};

