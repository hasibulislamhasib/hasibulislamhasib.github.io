import React, { useState, useEffect } from 'react';
import { ThemeMode } from '../types';

interface SubtleBackgroundProps {
  theme: ThemeMode;
  customPhotoUrl?: string | null;
}

export const PRIMARY_PHOTO_PATH = '/hasib-photo.jpg';
export const ALT_PHOTO_PATH = '/hasibul islam hasib pic.jpeg';
export const FALLBACK_PHOTO_PATH = '/hasib-photo.svg';

export const SubtleBackground: React.FC<SubtleBackgroundProps> = ({
  theme,
  customPhotoUrl,
}) => {
  const [imgSrc, setImgSrc] = useState<string>(
    customPhotoUrl || PRIMARY_PHOTO_PATH
  );
  const [triedAlt, setTriedAlt] = useState(false);

  useEffect(() => {
    if (customPhotoUrl) {
      setImgSrc(customPhotoUrl);
    }
  }, [customPhotoUrl]);

  const handleImageError = () => {
    if (!triedAlt && imgSrc === PRIMARY_PHOTO_PATH) {
      setTriedAlt(true);
      setImgSrc(ALT_PHOTO_PATH);
    } else if (imgSrc !== FALLBACK_PHOTO_PATH) {
      setImgSrc(FALLBACK_PHOTO_PATH);
    }
  };

  return (
    <div
      id="subtle-background-container"
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden select-none"
      aria-hidden="true"
    >
      {/* 1. Base Luxury Canvas */}
      <div
        className={`absolute inset-0 transition-colors duration-700 ${
          theme === 'dark' ? 'bg-[#070908]' : 'bg-[#f8faf8]'
        }`}
      />

      {/* 2. Soft Ambient Emerald Light Glows & Faint Light Streams */}
      {theme === 'dark' ? (
        <>
          {/* Top header ambient emerald pool */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-[520px] bg-[radial-gradient(ellipse_60%_45%_at_50%_0%,rgba(6,95,70,0.24),transparent_70%)]" />
          
          {/* Right-side depth glow behind hero/profile presence */}
          <div className="absolute top-1/4 right-0 w-[550px] h-[550px] bg-[radial-gradient(circle_at_75%_40%,rgba(5,150,105,0.11),transparent_65%)]" />
          
          {/* Lower left subtle grounding glow */}
          <div className="absolute bottom-10 left-0 w-[500px] h-[500px] bg-[radial-gradient(circle_at_20%_80%,rgba(4,120,87,0.08),transparent_60%)]" />

          {/* Faint luxury linear light effect (static, elegant diagonal gradient) */}
          <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(16,185,129,0.035)_0%,transparent_35%,rgba(5,150,105,0.02)_65%,transparent_100%)]" />

          {/* Deep perimeter vignette framing the content */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(5,7,6,0.85)_100%)]" />
        </>
      ) : (
        <>
          {/* Light mode refined ambient wash */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-[480px] bg-[radial-gradient(ellipse_60%_40%_at_50%_0%,rgba(16,185,129,0.07),transparent_70%)]" />
          <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-[radial-gradient(circle_at_80%_40%,rgba(5,150,105,0.045),transparent_65%)]" />
          <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(16,185,129,0.02)_0%,transparent_40%,rgba(5,150,105,0.015)_80%,transparent_100%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(240,244,241,0.6)_100%)]" />
        </>
      )}

      {/* 3. Personal Photo: Deeply Integrated, Recognizeable, and Highly Readable */}
      <div
        className={`absolute inset-0 transition-opacity duration-700 flex items-center justify-end ${
          theme === 'dark' ? 'opacity-[0.15]' : 'opacity-[0.07]'
        }`}
      >
        <img
          src={imgSrc}
          alt="Hasib Islam Subtle Portrait"
          onError={handleImageError}
          className="h-full w-full object-cover object-[68%_24%] sm:object-[72%_24%] md:object-[76%_28%] filter blur-[1.2px] scale-[1.02] transition-all duration-700"
          loading="eager"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* 4. Directional Readability Overlays (Dark / Light) */}
      {theme === 'dark' ? (
        <>
          {/* Horizontal gradient ensuring left text side has 100% solid contrast */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#070908] via-[#070908]/90 to-[#070908]/65" />
          {/* Vertical gradient connecting sections smoothly */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#070908]/80 via-transparent to-[#070908]/90" />
        </>
      ) : (
        <>
          {/* Light mode solid contrast wash */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#f8faf8] via-[#f8faf8]/92 to-[#f8faf8]/70" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#f8faf8]/85 via-transparent to-[#f8faf8]/95" />
        </>
      )}
    </div>
  );
};


