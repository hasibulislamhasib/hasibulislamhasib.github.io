import React, { useState } from 'react';
import {
  Sparkles,
  LayoutTemplate,
  Image as ImageIcon,
  FileText,
  Palette,
  MonitorSmartphone,
  Video,
  Camera,
  Check,
} from 'lucide-react';
import { ThemeMode, SkillItem } from '../types';
import { SKILLS_LIST } from '../portfolioData';

interface SkillsProps {
  theme: ThemeMode;
}

export const Skills: React.FC<SkillsProps> = ({ theme }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Design', 'Visual & Media', 'Development'];

  const filteredSkills =
    selectedCategory === 'All'
      ? SKILLS_LIST
      : SKILLS_LIST.filter((skill) => skill.category === selectedCategory);

  const renderIcon = (iconName: string) => {
    const iconClass = 'w-6 h-6 text-emerald-400';
    switch (iconName) {
      case 'LayoutTemplate':
        return <LayoutTemplate className={iconClass} />;
      case 'Image':
        return <ImageIcon className={iconClass} />;
      case 'FileText':
        return <FileText className={iconClass} />;
      case 'Palette':
        return <Palette className={iconClass} />;
      case 'MonitorSmartphone':
        return <MonitorSmartphone className={iconClass} />;
      case 'Video':
        return <Video className={iconClass} />;
      case 'Camera':
        return <Camera className={iconClass} />;
      default:
        return <Sparkles className={iconClass} />;
    }
  };

  return (
    <section
      id="skills"
      className="relative py-24 px-4 sm:px-6 lg:px-8 border-t border-emerald-500/10"
    >
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div
            className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border mb-3 transition-colors ${
              theme === 'dark'
                ? 'border-emerald-500/30 bg-emerald-950/40 text-emerald-300'
                : 'border-emerald-900/15 bg-white text-emerald-800 shadow-sm'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider">
              Core Capabilities
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
              theme === 'dark' ? 'text-white' : 'text-neutral-900'
            }`}
          >
            Skills &amp; Creative Tools
          </h2>
          <p
            className={`mt-2.5 text-sm sm:text-base ${
              theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Honest visual and technical skill set focused on design, media creation, and modern web interfaces.
          </p>

          {/* Category Filter Pills */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                id={`filter-skills-${cat.toLowerCase().replace(/[^a-z]/g, '-')}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-emerald-500 text-neutral-950 shadow-[0_2px_12px_rgba(16,185,129,0.35)]'
                    : theme === 'dark'
                    ? 'bg-[#0a0e0b]/80 border border-emerald-500/15 text-neutral-300 hover:text-white hover:border-emerald-500/35'
                    : 'bg-white border border-emerald-900/10 text-neutral-700 hover:text-emerald-800 shadow-sm'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Skills Cards Grid - No fake percentage bars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSkills.map((skill: SkillItem) => (
            <div
              key={skill.id}
              id={`skill-card-${skill.id}`}
              className={`p-6 sm:p-7 rounded-2xl border transition-all duration-300 flex flex-col justify-between group ${
                theme === 'dark'
                  ? 'bg-[#0a0e0b]/85 border-emerald-500/15 shadow-[0_4px_24px_rgba(0,0,0,0.4)] hover:border-emerald-500/40 hover:shadow-[0_8px_32px_rgba(16,185,129,0.12)] hover:-translate-y-0.5'
                  : 'bg-white/95 border-emerald-900/10 shadow-[0_4px_20px_rgba(5,150,105,0.06)] hover:border-emerald-600/30 hover:shadow-[0_8px_30px_rgba(5,150,105,0.12)] hover:-translate-y-0.5'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="p-3 rounded-xl border border-emerald-500/30 bg-emerald-950/40 shrink-0 shadow-[0_0_12px_rgba(16,185,129,0.12)] group-hover:border-emerald-400 transition-colors">
                    {renderIcon(skill.iconName)}
                  </div>
                  <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {skill.category}
                  </span>
                </div>

                <h3
                  className={`text-lg font-bold mb-2 tracking-tight ${
                    theme === 'dark' ? 'text-white' : 'text-neutral-900'
                  }`}
                >
                  {skill.name}
                </h3>

                <p
                  className={`text-xs sm:text-sm leading-relaxed ${
                    theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                  }`}
                >
                  {skill.description}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-emerald-500/15 flex items-center justify-between text-xs text-emerald-500 font-semibold">
                <div className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Active creative skillset</span>
                </div>
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
