import React, { useState } from 'react';
import {
  Phone,
  MessageCircle,
  ExternalLink,
  MapPin,
  Copy,
  Check,
  Share2,
} from 'lucide-react';
import { ThemeMode } from '../types';
import { PORTFOLIO_DATA } from '../portfolioData';

interface ContactProps {
  theme: ThemeMode;
}

export const Contact: React.FC<ContactProps> = ({ theme }) => {
  const [copied, setCopied] = useState(false);

  const copyPhoneNumber = () => {
    navigator.clipboard.writeText(PORTFOLIO_DATA.phone).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  return (
    <section
      id="contact"
      className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-emerald-500/10"
    >
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 mb-3">
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span
              className={`text-xs font-semibold uppercase tracking-wider ${
                theme === 'dark' ? 'text-emerald-300' : 'text-emerald-800'
              }`}
            >
              Get In Touch
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-bold tracking-tight ${
              theme === 'dark' ? 'text-neutral-100' : 'text-neutral-900'
            }`}
          >
            Direct Contact &amp; Social
          </h2>
          <p
            className={`mt-2 text-sm sm:text-base ${
              theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Feel free to connect directly via phone call, WhatsApp, or Facebook.
          </p>
        </div>

        {/* Primary Contact Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Direct Phone Dialer Card */}
          <div
            id="contact-phone-card"
            className={`p-7 sm:p-8 rounded-2xl border transition-all duration-300 flex flex-col justify-between ${
              theme === 'dark'
                ? 'bg-[#0a0e0b]/85 border-emerald-500/15 shadow-[0_8px_32px_rgba(0,0,0,0.5)] hover:border-emerald-500/40 hover:shadow-[0_8px_32px_rgba(16,185,129,0.12)]'
                : 'bg-white/95 border-emerald-900/10 shadow-[0_8px_30px_rgba(5,150,105,0.06)] hover:border-emerald-600/40'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="p-3 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                  <Phone className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Direct Line
                </span>
              </div>

              <h3
                className={`text-2xl font-bold mb-1.5 tracking-tight ${
                  theme === 'dark' ? 'text-white' : 'text-neutral-900'
                }`}
              >
                Phone Call
              </h3>
              <p
                className={`text-xs sm:text-sm mb-5 leading-relaxed ${
                  theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                }`}
              >
                Tap to dial directly from your mobile device or desktop.
              </p>

              <div
                className={`p-4 rounded-xl border mb-6 flex items-center justify-between gap-3 ${
                  theme === 'dark'
                    ? 'bg-[#070908] border-emerald-500/20'
                    : 'bg-neutral-50 border-emerald-900/10'
                }`}
              >
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-emerald-500 font-semibold mb-0.5">
                    Phone Number
                  </div>
                  <a
                    id="direct-phone-link"
                    href={`tel:${PORTFOLIO_DATA.phone}`}
                    className="text-lg font-mono font-bold tracking-wider text-emerald-400 hover:text-emerald-300 hover:underline"
                  >
                    {PORTFOLIO_DATA.phone}
                  </a>
                </div>

                <button
                  type="button"
                  id="copy-phone-btn"
                  onClick={copyPhoneNumber}
                  aria-label="Copy phone number"
                  className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all duration-200 cursor-pointer ${
                    copied
                      ? 'border-emerald-400 bg-emerald-500/20 text-emerald-300'
                      : theme === 'dark'
                      ? 'border-emerald-500/30 bg-emerald-950/40 text-neutral-300 hover:text-white hover:border-emerald-400'
                      : 'border-neutral-200 bg-white text-neutral-700 hover:text-neutral-950 shadow-sm'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <a
              id="call-now-action-btn"
              href={`tel:${PORTFOLIO_DATA.phone}`}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-neutral-950 font-bold text-sm tracking-wide transition-all duration-300 text-center inline-flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_24px_rgba(5,150,105,0.25)] hover:shadow-[0_6px_30px_rgba(16,185,129,0.35)]"
            >
              <Phone className="w-4 h-4" />
              <span>Call {PORTFOLIO_DATA.phone}</span>
            </a>
          </div>

          {/* WhatsApp Direct Chat Card */}
          <div
            id="contact-whatsapp-card"
            className={`p-7 sm:p-8 rounded-2xl border transition-all duration-300 flex flex-col justify-between ${
              theme === 'dark'
                ? 'bg-[#0a0e0b]/85 border-emerald-500/15 shadow-[0_8px_32px_rgba(0,0,0,0.5)] hover:border-emerald-500/40 hover:shadow-[0_8px_32px_rgba(16,185,129,0.12)]'
                : 'bg-white/95 border-emerald-900/10 shadow-[0_8px_30px_rgba(5,150,105,0.06)] hover:border-emerald-600/40'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="p-3 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Instant Message
                </span>
              </div>

              <h3
                className={`text-2xl font-bold mb-1.5 tracking-tight ${
                  theme === 'dark' ? 'text-white' : 'text-neutral-900'
                }`}
              >
                WhatsApp Chat
              </h3>
              <p
                className={`text-xs sm:text-sm mb-5 leading-relaxed ${
                  theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                }`}
              >
                Instantly start a conversation on WhatsApp for queries and design projects.
              </p>

              <div
                className={`p-4 rounded-xl border mb-6 ${
                  theme === 'dark'
                    ? 'bg-[#070908] border-emerald-500/20'
                    : 'bg-neutral-50 border-emerald-900/10'
                }`}
              >
                <div className="text-[11px] uppercase tracking-wider text-emerald-500 font-semibold mb-0.5">
                  WhatsApp Number (Bangladesh)
                </div>
                <div className="text-lg font-mono font-bold tracking-wider text-emerald-400">
                  +880 {PORTFOLIO_DATA.phone.substring(1)}
                </div>
              </div>
            </div>

            <a
              id="whatsapp-chat-action-btn"
              href={`https://wa.me/${PORTFOLIO_DATA.whatsAppInternational}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 px-4 rounded-xl border border-emerald-500/40 bg-emerald-500/15 hover:bg-emerald-500 hover:text-neutral-950 text-emerald-400 font-bold text-sm tracking-wide transition-all duration-300 text-center inline-flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(16,185,129,0.15)] hover:shadow-[0_4px_24px_rgba(16,185,129,0.35)]"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Start WhatsApp Conversation</span>
            </a>
          </div>
        </div>

        {/* Social Media & Location Bar */}
        <div
          id="social-media-bar"
          className={`p-6 sm:p-7 rounded-2xl border transition-all duration-300 flex flex-col sm:flex-row items-center justify-between gap-6 ${
            theme === 'dark'
              ? 'bg-[#0a0e0b]/80 border-emerald-500/15 shadow-[0_4px_24px_rgba(0,0,0,0.4)]'
              : 'bg-white/95 border-emerald-900/10 shadow-[0_4px_20px_rgba(5,150,105,0.05)]'
          }`}
        >
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="p-3 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.15)]">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h4
                className={`text-base font-bold ${
                  theme === 'dark' ? 'text-white' : 'text-neutral-900'
                }`}
              >
                Social Connect
              </h4>
              <p
                className={`text-xs ${
                  theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                }`}
              >
                Follow personal design updates and activities.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Facebook Button */}
            <a
              id="contact-facebook-btn"
              href={PORTFOLIO_DATA.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500 hover:text-neutral-950 text-emerald-400 text-sm font-semibold transition-all duration-200 cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.15)]"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Facebook Profile</span>
            </a>

            {/* Location Pill */}
            <div className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-emerald-500/20 bg-emerald-950/30 text-xs font-semibold text-emerald-300">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              <span>{PORTFOLIO_DATA.location}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
