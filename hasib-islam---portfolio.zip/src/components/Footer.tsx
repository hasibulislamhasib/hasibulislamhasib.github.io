import React from 'react';
import { MessageCircle, ExternalLink, ArrowUp, Phone } from 'lucide-react';
import { ThemeMode } from '../types';
import { PORTFOLIO_DATA } from '../portfolioData';

interface FooterProps {
  theme: ThemeMode;
}

export const Footer: React.FC<FooterProps> = ({ theme }) => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <footer
      id="main-footer"
      className={`relative py-14 border-t transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-[#060807] border-emerald-500/15 text-neutral-400'
          : 'bg-[#f4f7f4] border-emerald-900/10 text-neutral-600'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Copyright and Identity */}
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2.5 mb-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold shadow-[0_0_10px_rgba(16,185,129,0.2)]">
                H
              </span>
              <span
                className={`font-bold text-sm tracking-tight ${
                  theme === 'dark' ? 'text-white' : 'text-neutral-900'
                }`}
              >
                {PORTFOLIO_DATA.displayName}
              </span>
            </div>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 light:text-neutral-500">
              &copy; 2026 {PORTFOLIO_DATA.fullName}. All rights reserved.
            </p>
          </div>

          {/* Social & Contact Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3">
            {/* WhatsApp button */}
            <a
              id="footer-whatsapp-btn"
              href={`https://wa.me/${PORTFOLIO_DATA.whatsAppInternational}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-neutral-950 transition-all duration-200"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>

            {/* Facebook button */}
            <a
              id="footer-facebook-btn"
              href={PORTFOLIO_DATA.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all duration-200 ${
                theme === 'dark'
                  ? 'border-emerald-500/20 bg-[#0a0e0b] text-neutral-300 hover:text-emerald-400 hover:border-emerald-500/40'
                  : 'border-emerald-900/15 bg-white text-neutral-700 hover:text-emerald-700 shadow-sm'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Facebook</span>
            </a>

            {/* Phone button */}
            <a
              id="footer-phone-btn"
              href={`tel:${PORTFOLIO_DATA.phone}`}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all duration-200 ${
                theme === 'dark'
                  ? 'border-emerald-500/20 bg-[#0a0e0b] text-neutral-300 hover:text-emerald-400 hover:border-emerald-500/40'
                  : 'border-emerald-900/15 bg-white text-neutral-700 hover:text-emerald-700 shadow-sm'
              }`}
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{PORTFOLIO_DATA.phone}</span>
            </a>

            {/* Back to top button */}
            <button
              id="footer-back-to-top"
              type="button"
              onClick={scrollToTop}
              aria-label="Back to top"
              className={`p-2.5 rounded-xl border transition-all duration-200 cursor-pointer ${
                theme === 'dark'
                  ? 'border-emerald-500/20 bg-[#0a0e0b] text-neutral-300 hover:border-emerald-400 hover:text-emerald-400 hover:shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                  : 'border-emerald-900/15 bg-white text-neutral-700 hover:border-emerald-600 hover:text-emerald-700 shadow-sm'
              }`}
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

