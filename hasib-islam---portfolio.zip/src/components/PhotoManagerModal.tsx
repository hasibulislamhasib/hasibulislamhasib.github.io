import React, { useRef } from 'react';
import { Image, Upload, X, Check, HelpCircle, RefreshCw } from 'lucide-react';
import { ThemeMode } from '../types';
import { PRIMARY_PHOTO_PATH } from './SubtleBackground';

interface PhotoManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  customPhotoUrl: string | null;
  onSelectCustomPhoto: (dataUrl: string | null) => void;
}

export const PhotoManagerModal: React.FC<PhotoManagerModalProps> = ({
  isOpen,
  onClose,
  theme,
  customPhotoUrl,
  onSelectCustomPhoto,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        onSelectCustomPhoto(result);
        // Persist to server if available
        fetch('/api/upload-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ dataUrl: result }),
        }).catch(() => {
          // LocalStorage fallback already set
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    onSelectCustomPhoto(null);
  };

  return (
    <div
      id="photo-manager-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="photo-modal-title"
    >
      <div
        id="photo-manager-modal-card"
        className={`relative w-full max-w-lg rounded-2xl border p-6 sm:p-7 shadow-2xl transition-all ${
          theme === 'dark'
            ? 'bg-neutral-900 border-neutral-800 text-neutral-100'
            : 'bg-white border-neutral-200 text-neutral-900'
        }`}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-5 right-5 p-1.5 rounded-lg text-neutral-400 hover:text-neutral-100 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <Image className="w-5 h-5" />
          </div>
          <div>
            <h3 id="photo-modal-title" className="text-lg font-bold">
              Personal Background Photo Settings
            </h3>
            <p className="text-xs text-neutral-400">
              Integrate your personal photo as a subtle texture
            </p>
          </div>
        </div>

        {/* Explanation of static file location */}
        <div
          className={`p-4 rounded-xl border mb-5 text-xs leading-relaxed ${
            theme === 'dark'
              ? 'bg-neutral-950 border-neutral-800 text-neutral-300'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700'
          }`}
        >
          <div className="flex items-center gap-2 font-semibold text-emerald-500 mb-1">
            <HelpCircle className="w-4 h-4 shrink-0" />
            <span>Permanent Image File Reference</span>
          </div>
          <p>
            To use your permanent photo, save your file inside the project folder at:
          </p>
          <div className="mt-2 p-2 rounded bg-neutral-900 dark:bg-black font-mono text-[12px] text-emerald-400 border border-emerald-500/20 break-all select-all">
            public{PRIMARY_PHOTO_PATH}
          </div>
          <p className="mt-2 text-[11px] text-neutral-400">
            The website automatically renders this file as a subtle, low-opacity, high-readability background texture.
          </p>
        </div>

        {/* Live upload preview */}
        <div className="space-y-3 mb-6">
          <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Live Preview From Your Device
          </div>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
            id="photo-file-upload-input"
          />

          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              id="select-photo-btn"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-semibold text-xs transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{customPhotoUrl ? 'Choose Another Photo' : 'Select Photo to Preview'}</span>
            </button>

            {customPhotoUrl && (
              <button
                type="button"
                id="reset-photo-btn"
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-neutral-700 text-xs text-neutral-300 hover:text-white cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset to Default</span>
              </button>
            )}
          </div>

          {customPhotoUrl ? (
            <div className="flex items-center gap-2 text-xs text-emerald-400 mt-2">
              <Check className="w-4 h-4" />
              <span>Your personal photo is now applied as the subtle background.</span>
            </div>
          ) : (
            <p className="text-[11px] text-neutral-500">
              No custom photo selected yet. Default subtle background texture is currently active.
            </p>
          )}
        </div>

        {/* Action button */}
        <div className="flex justify-end pt-2 border-t border-neutral-800">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
