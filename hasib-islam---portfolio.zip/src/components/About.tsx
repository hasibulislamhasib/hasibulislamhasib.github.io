import React from 'react';
import { User, Target, BookOpen, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';
import { ThemeMode } from '../types';
import { PORTFOLIO_DATA } from '../portfolioData';

interface AboutProps {
  theme: ThemeMode;
}

export const About: React.FC<AboutProps> = ({ theme }) => {
  return (
    <section
      id="about"
      className="relative py-24 px-4 sm:px-6 lg:px-8 border-t border-emerald-500/10"
    >
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div
            className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border mb-3 transition-colors ${
              theme === 'dark'
                ? 'border-emerald-500/30 bg-emerald-950/40 text-emerald-300'
                : 'border-emerald-900/15 bg-white text-emerald-800 shadow-sm'
            }`}
          >
            <User className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider">
              About Me
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
              theme === 'dark' ? 'text-white' : 'text-neutral-900'
            }`}
          >
            HM Hasibul Islam Hasib
          </h2>
          <p
            className={`mt-2.5 text-sm sm:text-base ${
              theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Known as <span className="font-semibold text-emerald-500">{PORTFOLIO_DATA.nickname}</span> • Based in {PORTFOLIO_DATA.location}
          </p>
        </div>

        {/* Biography and Facts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
          {/* Main Biography Column */}
          <div
            className={`lg:col-span-7 p-7 sm:p-9 rounded-2xl border transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-[#0a0e0b]/85 border-emerald-500/15 text-neutral-200 shadow-[0_8px_32px_rgba(0,0,0,0.5)] hover:border-emerald-500/30'
                : 'bg-white/95 border-emerald-900/10 text-neutral-800 shadow-[0_8px_30px_rgba(5,150,105,0.06)] hover:border-emerald-600/30'
            }`}
          >
            <h3
              className={`text-xl font-bold mb-4 flex items-center gap-2.5 ${
                theme === 'dark' ? 'text-emerald-400' : 'text-emerald-700'
              }`}
            >
              <Sparkles className="w-5 h-5" />
              Creative Background
            </h3>

            <div className="space-y-4 text-sm sm:text-base leading-relaxed">
              <p className={theme === 'dark' ? 'text-neutral-300' : 'text-neutral-700'}>
                My full name is{' '}
                <strong className={theme === 'dark' ? 'text-white font-semibold' : 'text-neutral-950 font-semibold'}>
                  HM Hasibul Islam Hasib
                </strong>
                . I am a creative person passionate about visual arts, poster design, graphic design, and web design from Dinajpur, Bangladesh.
              </p>
              <p className={theme === 'dark' ? 'text-neutral-300' : 'text-neutral-700'}>
                I believe in expressing thoughtful ideas through clean, harmonious designs while actively challenging myself to acquire new knowledge every day.
              </p>
              <p className={theme === 'dark' ? 'text-neutral-300' : 'text-neutral-700'}>
                Presently, I work as a{' '}
                <span className="font-semibold text-emerald-500">
                  Poster Designer, Graphic Designer, and Web Designer
                </span>
                . I am actively investing my time into learning deeper web design practices with the determined ambition of growing into a{' '}
                <strong className={theme === 'dark' ? 'text-white font-semibold' : 'text-neutral-950 font-semibold'}>
                  professional web developer
                </strong>
                .
              </p>
            </div>

            {/* Core Values / Principles */}
            <div className="mt-8 pt-6 border-t border-emerald-500/15 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Continuous Learning</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Thoughtful Visual Design</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Honest Craftsmanship</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Modern Web Focus</span>
              </div>
            </div>
          </div>

          {/* Quick Info & Goals Column */}
          <div className="lg:col-span-5 space-y-4">
            {/* Currently Learning Card */}
            <div
              className={`p-6 rounded-2xl border transition-all duration-300 ${
                theme === 'dark'
                  ? 'bg-[#0a0e0b]/85 border-emerald-500/15 shadow-[0_4px_24px_rgba(0,0,0,0.4)] hover:border-emerald-500/30'
                  : 'bg-white/95 border-emerald-900/10 shadow-[0_4px_20px_rgba(5,150,105,0.05)] hover:border-emerald-600/30'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 shrink-0 shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-500 mb-1">
                    Current Focus
                  </div>
                  <div
                    className={`text-base font-bold tracking-tight ${
                      theme === 'dark' ? 'text-white' : 'text-neutral-900'
                    }`}
                  >
                    Learning {PORTFOLIO_DATA.currentlyLearning}
                  </div>
                  <p
                    className={`mt-1.5 text-xs leading-relaxed ${
                      theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                    }`}
                  >
                    Developing practical understanding of web structure, typography, layout, and responsive digital interfaces.
                  </p>
                </div>
              </div>
            </div>

            {/* Future Goal Card */}
            <div
              className={`p-6 rounded-2xl border transition-all duration-300 ${
                theme === 'dark'
                  ? 'bg-[#0a0e0b]/85 border-emerald-500/15 shadow-[0_4px_24px_rgba(0,0,0,0.4)] hover:border-emerald-500/30'
                  : 'bg-white/95 border-emerald-900/10 shadow-[0_4px_20px_rgba(5,150,105,0.05)] hover:border-emerald-600/30'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 shrink-0 shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-500 mb-1">
                    Future Goal
                  </div>
                  <div
                    className={`text-base font-bold tracking-tight ${
                      theme === 'dark' ? 'text-white' : 'text-neutral-900'
                    }`}
                  >
                    {PORTFOLIO_DATA.futureGoal}
                  </div>
                  <p
                    className={`mt-1.5 text-xs leading-relaxed ${
                      theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                    }`}
                  >
                    Dedicated to advancing from visual design and interface crafting to complete, professional full-stack web development.
                  </p>
                </div>
              </div>
            </div>

            {/* Location & Academic Summary Card */}
            <div
              className={`p-6 rounded-2xl border transition-all duration-300 ${
                theme === 'dark'
                  ? 'bg-[#0a0e0b]/85 border-emerald-500/15 shadow-[0_4px_24px_rgba(0,0,0,0.4)] hover:border-emerald-500/30'
                  : 'bg-white/95 border-emerald-900/10 shadow-[0_4px_20px_rgba(5,150,105,0.05)] hover:border-emerald-600/30'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 shrink-0 shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-500 mb-1">
                    Location &amp; Education
                  </div>
                  <div
                    className={`text-sm font-bold ${
                      theme === 'dark' ? 'text-neutral-200' : 'text-neutral-900'
                    }`}
                  >
                    {PORTFOLIO_DATA.location}
                  </div>
                  <div className="mt-1 text-xs text-emerald-500 font-semibold">
                    {PORTFOLIO_DATA.qualifications}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

