import React, { useEffect, useState } from 'react';

interface LoadingScreenProps {
  onFinished: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onFinished }) => {
  const [fading, setFading] = useState(false);

  useEffect(() => {
    // Elegant brief loading timing (600ms load, then subtle 300ms fade)
    const timer = setTimeout(() => {
      setFading(true);
      const finishTimer = setTimeout(() => {
        onFinished();
      }, 350);
      return () => clearTimeout(finishTimer);
    }, 650);

    return () => clearTimeout(timer);
  }, [onFinished]);

  return (
    <div
      id="loading-screen"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-neutral-950 text-neutral-100 transition-opacity duration-300 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      aria-label="Loading portfolio"
    >
      <div className="flex flex-col items-center gap-6">
        {/* Monogram / Brand mark */}
        <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl border border-emerald-500/30 bg-neutral-900/80 shadow-lg shadow-emerald-950/40">
          <span className="font-mono text-2xl font-bold tracking-wider text-emerald-400">
            H
          </span>
          <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-500" />
        </div>

        {/* Display name */}
        <div className="text-center">
          <h1 className="text-xl font-bold tracking-[0.2em] text-neutral-100 uppercase">
            Hasib Islam
          </h1>
          <p className="mt-1 text-xs tracking-widest text-emerald-400/80 uppercase">
            Creative Portfolio
          </p>
        </div>

        {/* Subtle loading line */}
        <div className="w-36 h-1 rounded-full bg-neutral-800 overflow-hidden">
          <div className="h-full bg-emerald-500 w-full animate-pulse transition-all duration-500" />
        </div>
      </div>
    </div>
  );
};
