import React, { useState, useEffect } from 'react';
import { Sun, Moon, Menu, X, Phone, MessageCircle } from 'lucide-react';
import { ThemeMode } from '../types';
import { PORTFOLIO_DATA } from '../portfolioData';

interface NavbarProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  theme,
  onToggleTheme,
  activeSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Education', href: '#education' },
    { name: 'Contact', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      const navOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled
          ? theme === 'dark'
            ? 'bg-[#070908]/90 backdrop-blur-xl border-b border-emerald-500/15 shadow-[0_10px_30px_rgba(0,0,0,0.6)]'
            : 'bg-[#f8faf8]/90 backdrop-blur-xl border-b border-emerald-900/10 shadow-[0_10px_30px_rgba(5,150,105,0.05)]'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand / Logo */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            scrollToSection('#home');
          }}
          className="group flex items-center gap-3 cursor-pointer select-none"
          id="nav-logo-link"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-500/30 bg-emerald-950/40 text-emerald-400 font-mono font-bold text-lg shadow-[0_0_15px_rgba(16,185,129,0.15)] transition-all duration-300 group-hover:border-emerald-400 group-hover:bg-emerald-900/50 group-hover:shadow-[0_0_20px_rgba(16,185,129,0.3)]">
            H
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#070908]" />
          </div>
          <div>
            <span
              className={`font-semibold tracking-tight text-base sm:text-lg block leading-tight ${
                theme === 'dark' ? 'text-white' : 'text-neutral-900'
              }`}
            >
              {PORTFOLIO_DATA.displayName}
            </span>
            <span className="text-[11px] font-medium text-emerald-500 tracking-wider uppercase">
              Designer &amp; Creator
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav
          className={`hidden md:flex items-center gap-1 rounded-full px-3 py-1.5 border transition-colors ${
            theme === 'dark'
              ? 'border-emerald-500/15 bg-[#0b0e0c]/80 backdrop-blur-md shadow-inner'
              : 'border-emerald-900/10 bg-white/80 backdrop-blur-md shadow-sm'
          }`}
          id="desktop-nav-menu"
        >
          {navLinks.map((link) => {
            const isActive = activeSection === link.href.replace('#', '');
            return (
              <button
                key={link.name}
                id={`nav-link-${link.name.toLowerCase()}`}
                onClick={() => scrollToSection(link.href)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-neutral-950 shadow-[0_2px_12px_rgba(16,185,129,0.35)]'
                    : theme === 'dark'
                    ? 'text-neutral-300 hover:text-emerald-400 hover:bg-emerald-950/30'
                    : 'text-neutral-700 hover:text-emerald-800 hover:bg-emerald-50'
                }`}
              >
                {link.name}
              </button>
            );
          })}
        </nav>

        {/* Header Right Actions: WhatsApp & Luxury Theme Switch */}
        <div className="flex items-center gap-3">
          {/* Quick WhatsApp button */}
          <a
            id="nav-whatsapp-btn"
            href={`https://wa.me/${PORTFOLIO_DATA.whatsAppInternational}`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="WhatsApp Chat"
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-neutral-950 hover:shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all duration-200 whitespace-nowrap"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>

          {/* Premium Segmented Theme Toggle Switch */}
          <div
            id="theme-toggle-switch-wrapper"
            className={`flex items-center p-1 rounded-full border transition-all duration-300 ${
              theme === 'dark'
                ? 'border-emerald-500/20 bg-[#0b0e0c]/90 shadow-inner'
                : 'border-emerald-900/15 bg-white shadow-sm'
            }`}
          >
            <button
              id="theme-btn-dark"
              type="button"
              onClick={() => theme !== 'dark' && onToggleTheme()}
              aria-label="Switch to Dark Mode"
              className={`relative flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer ${
                theme === 'dark'
                  ? 'bg-emerald-500/20 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.25)] border border-emerald-500/30'
                  : 'text-neutral-400 hover:text-neutral-600'
              }`}
            >
              <Moon className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden lg:inline text-[11px] font-semibold">Dark</span>
            </button>

            <button
              id="theme-btn-light"
              type="button"
              onClick={() => theme !== 'light' && onToggleTheme()}
              aria-label="Switch to Light Mode"
              className={`relative flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer ${
                theme === 'light'
                  ? 'bg-emerald-600 text-white shadow-[0_0_10px_rgba(5,150,105,0.25)]'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Sun className="w-3.5 h-3.5 text-emerald-300" />
              <span className="hidden lg:inline text-[11px] font-semibold">Light</span>
            </button>
          </div>

          {/* Mobile Hamburger Menu Button */}
          <button
            id="mobile-menu-toggle"
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle navigation menu"
            className={`md:hidden p-2 rounded-xl border transition-colors cursor-pointer ${
              theme === 'dark'
                ? 'border-emerald-500/20 bg-[#0d120f] text-neutral-200 hover:text-emerald-400'
                : 'border-emerald-900/15 bg-white text-neutral-800 shadow-sm hover:text-emerald-700'
            }`}
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5 text-emerald-400" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className={`md:hidden px-4 pt-3 pb-6 border-b transition-all duration-300 ${
            theme === 'dark'
              ? 'bg-[#070908]/98 border-emerald-500/20 shadow-2xl backdrop-blur-xl'
              : 'bg-[#f8faf8]/98 border-emerald-900/10 shadow-2xl backdrop-blur-xl'
          }`}
        >
          <div className="flex flex-col space-y-2">
            {navLinks.map((link) => {
              const isActive = activeSection === link.href.replace('#', '');
              return (
                <button
                  key={link.name}
                  id={`mobile-nav-link-${link.name.toLowerCase()}`}
                  onClick={() => scrollToSection(link.href)}
                  className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500 text-neutral-950 shadow-[0_2px_12px_rgba(16,185,129,0.3)]'
                      : theme === 'dark'
                      ? 'text-neutral-300 hover:bg-emerald-950/30 hover:text-emerald-400'
                      : 'text-neutral-700 hover:bg-emerald-50 hover:text-emerald-800'
                  }`}
                >
                  {link.name}
                </button>
              );
            })}

            <div className="pt-3 mt-2 border-t border-emerald-500/15 grid grid-cols-2 gap-2">
              <a
                id="mobile-drawer-call-btn"
                href={`tel:${PORTFOLIO_DATA.phone}`}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-center"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Now</span>
              </a>
              <a
                id="mobile-drawer-whatsapp-btn"
                href={`https://wa.me/${PORTFOLIO_DATA.whatsAppInternational}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold bg-emerald-500 text-neutral-950 text-center font-bold shadow-[0_2px_10px_rgba(16,185,129,0.3)]"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

