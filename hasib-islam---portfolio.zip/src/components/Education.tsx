import React from 'react';
import { GraduationCap, Award, Calendar, CheckCircle } from 'lucide-react';
import { ThemeMode } from '../types';
import { EDUCATION_LIST } from '../portfolioData';

interface EducationProps {
  theme: ThemeMode;
}

export const Education: React.FC<EducationProps> = ({ theme }) => {
  return (
    <section
      id="education"
      className="relative py-24 px-4 sm:px-6 lg:px-8 border-t border-emerald-500/10"
    >
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div
            className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border mb-3 transition-colors ${
              theme === 'dark'
                ? 'border-emerald-500/30 bg-emerald-950/40 text-emerald-300'
                : 'border-emerald-900/15 bg-white text-emerald-800 shadow-sm'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider">
              Academic Background
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
              theme === 'dark' ? 'text-white' : 'text-neutral-900'
            }`}
          >
            Education &amp; Qualifications
          </h2>
          <p
            className={`mt-2.5 text-sm sm:text-base ${
              theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Faithful educational path and ongoing academic milestones.
          </p>
        </div>

        {/* Timeline Layout */}
        <div className="relative border-l-2 border-emerald-500/30 ml-4 sm:ml-8 pl-6 sm:pl-10 space-y-10">
          {EDUCATION_LIST.map((item, index) => (
            <div key={item.title} className="relative group">
              {/* Timeline marker node */}
              <div className="absolute -left-[31px] sm:-left-[47px] top-1.5 flex h-7 w-7 items-center justify-center rounded-full border-2 border-emerald-400 bg-[#070908] text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.5)]">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>

              {/* Education Card */}
              <div
                id={`education-card-${index}`}
                className={`p-7 sm:p-8 rounded-2xl border transition-all duration-300 ${
                  theme === 'dark'
                    ? 'bg-[#0a0e0b]/85 border-emerald-500/15 text-neutral-200 shadow-[0_8px_32px_rgba(0,0,0,0.5)] hover:border-emerald-500/35 hover:shadow-[0_8px_32px_rgba(16,185,129,0.1)]'
                    : 'bg-white/95 border-emerald-900/10 text-neutral-800 shadow-[0_8px_30px_rgba(5,150,105,0.06)] hover:border-emerald-600/30'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                  <span className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5" />
                    {item.badge}
                  </span>

                  <div className="flex items-center gap-1.5 text-xs text-emerald-500 font-semibold">
                    {item.status === 'Completed' ? (
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                    )}
                    <span>{item.status}</span>
                  </div>
                </div>

                <h3
                  className={`text-2xl font-bold tracking-tight mb-1.5 ${
                    theme === 'dark' ? 'text-white' : 'text-neutral-950'
                  }`}
                >
                  {item.title}
                </h3>

                <h4 className="text-sm font-semibold text-emerald-500 mb-3">
                  {item.subtitle}
                </h4>

                <p
                  className={`text-sm leading-relaxed ${
                    theme === 'dark' ? 'text-neutral-400' : 'text-neutral-600'
                  }`}
                >
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

